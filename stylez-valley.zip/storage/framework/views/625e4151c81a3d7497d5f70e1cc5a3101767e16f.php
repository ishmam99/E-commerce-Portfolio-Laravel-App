
<?php $__env->startSection('main'); ?>
   
    
        <main class="main">
            <div class="category-banner-container bg-gray">
                <div class="category-banner banner text-uppercase" >
                    <div class="container position-relative">
                        <div class="row">
                            
                            <div class="pl-lg-3 col-md-4 offset-md-0 offset-1 pt-3">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <nav aria-label="breadcrumb" class="breadcrumb-nav">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Products</li>
                    </ol>
                </nav>

                 <div class="product-single-container product-single-default">
                    <div class="cart-message d-none">
                        <strong class="single-cart-notice">“<?php echo e($product->name); ?>”</strong>
                      
                    </div>

                    <div class="row">
                        <div class="col-lg-5 col-md-6 product-single-gallery">
                            <div class="product-slider-container">
                                

                                <div class="product-single-carousel owl-carousel owl-theme show-nav-hover">
                                    <div class="product-item">
                                        <img class="product-single-image" src="<?php echo e(setImage($product->image_one)); ?>" data-zoom-image="<?php echo e(setImage($product->image_one)); ?>" width="468" height="468" alt="product" />
                                    </div>
                                    <div class="product-item">
                                        <img class="product-single-image" src="<?php echo e(setImage($product->image_two)); ?>" data-zoom-image="<?php echo e(setImage($product->image_two)); ?>" width="468" height="468" alt="product" />
                                    </div>
                                    <div class="product-item">
                                        <img class="product-single-image" src="<?php echo e(setImage($product->image_three)); ?>" data-zoom-image="<?php echo e(setImage($product->image_three)); ?>" width="468" height="468" alt="product" />
                                    </div>
                                    
                                </div>
                                <!-- End .product-single-carousel -->
                                <span class="prod-full-screen">
									<i class="icon-plus"></i>
								</span>
                            </div>

                            <div class="prod-thumbnail owl-dots">
                                <div class="owl-dot">
                                    <img src="<?php echo e(setImage($product->image_one)); ?>" width="110" height="110" alt="product-thumbnail" />
                                </div>
                                <div class="owl-dot">
                                    <img src="<?php echo e(setImage($product->image_two)); ?>" width="110" height="110" alt="product-thumbnail" />
                                </div>
                                <div class="owl-dot">
                                    <img src="<?php echo e(setImage($product->image_three)); ?>" width="110" height="110" alt="product-thumbnail" />
                                </div>
                                
                            </div>
                        </div>
                        <!-- End .product-single-gallery -->

                        <div class="col-lg-7 col-md-6 product-single-details">
                            <h1 class="product-title"><?php echo e($product->name); ?></h1>

                            <div class="product-nav">
                                <div class="product-prev">
                                    <a href="#">
                                        <span class="product-link"></span>

                                        <span class="product-popup">
											<span class="box-content">
												<img alt="product" width="150" height="150"
													src="assets/images/products/product-3.jpg"
													style="padding-top: 0px;">

												<span>Circled Ultimate 3D Speaker</span>
                                        </span>
                                        </span>
                                    </a>
                                </div>

                                <div class="product-next">
                                    <a href="#">
                                        <span class="product-link"></span>

                                        <span class="product-popup">
											<span class="box-content">
												<img alt="product" width="150" height="150"
													src="assets/images/products/product-4.jpg"
													style="padding-top: 0px;">

												<span>Blue Backpack for the Young</span>
                                        </span>
                                        </span>
                                    </a>
                                </div>
                            </div>

                            <div class="ratings-container">
                                <div class="product-ratings">
                                    <span class="ratings" style="width:60%"></span>
                                    <!-- End .ratings -->
                                    <span class="tooltiptext tooltip-top"></span>
                                </div>
                                <!-- End .product-ratings -->

                                
                            </div>
                            <!-- End .ratings-container -->

                            <hr class="short-divider">

                            <div class="price-box">
                                
                                <span class="new-price">$<?php echo e($product->price); ?></span>
                            </div>
                            <!-- End .price-box -->

                            <div class="product-desc">
                                <p>
                                   <?php echo $product->details; ?>

                                </p>
                            </div>
                            <!-- End .product-desc -->

                            <ul class="single-info-list">

                                

                                <li>
                                    CATEGORY: <strong><a href="#" class="product-category"><?php echo e($product->subCategory->name); ?></a></strong>
                                </li>

                                
                            </ul>

                            
                            <!-- End .product-action -->

                            <hr class="divider mb-0 mt-0">

                            
                            <!-- End .product single-share -->
                        </div>
                        <!-- End .product-single-details -->
                    </div>
                    <!-- End .row -->
                </div>
            </div>
            <!-- End .container -->
            
            <!-- End .col-lg-3 -->

            <div class="mb-3"></div>
            <!-- margin -->
        </main>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.includes.website.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spinnertechltd/stylez-valley.spinnertechltd.com/resources/views/website/product_single.blade.php ENDPATH**/ ?>