<div class="home-slider slide-animate owl-carousel owl-theme show-nav-hover nav-big">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
                <div class="home-slide home-slide1 banner d-flex align-items-center" >
                    <img class="slide-bg" src="<?php echo e(setImage($slider->photo)); ?>"
                        style="background-color: #ecc;" alt="home banner">
                    <div class="banner-layer appear-animate" data-animation-name="fadeInUpShorter">
                        <!--<h2 style="color:<?php echo e($slider->color); ?>"><?php echo e($slider->name); ?></h2>-->
                        <!--<h3 class="text-uppercase mb-0" style="color:<?php echo e($slider->color); ?>"><?php echo e($slider->discount); ?></h3>-->
                        <!--<h4 class="m-b-4" style="color:<?php echo e($slider->color); ?>"><?php echo e($slider->product); ?></h4>-->

                        <!---->
                        <!--<a href="<?php echo e(route('products')); ?>" class="btn btn-dark btn-xl" role="button">Shop Now</a>-->
                    </div><!-- End .banner-layer -->
                </div><!-- End .home-slide -->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><?php /**PATH D:\Laravel\stylez-valley\resources\views/layouts/includes/website/slider.blade.php ENDPATH**/ ?>