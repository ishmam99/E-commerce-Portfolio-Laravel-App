<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from portotheme.com/html/porto_ecommerce/demo3.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Mar 2022 07:08:10 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Stylez Valley</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Porto - Bootstrap eCommerce Template">
    <meta name="author" content="SW-THEMES">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/website/assets/images/icons/favicon.png')); ?>">

    <script>
        WebFontConfig = {
            google: { families: [ 'Open+Sans:300,400,600,700,800', 'Poppins:300,400,500,600,700' ] }
        };
        ( function ( d ) {
            var wf = d.createElement( 'script' ), s = d.scripts[ 0 ];
            wf.src = '<?php echo e(asset('assets/website/assets/js/webfont.js')); ?>';
            wf.async = true;
            s.parentNode.insertBefore( wf, s );
        } )( document );
    </script>

    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/assets/css/bootstrap.min.css')); ?>">

    <!-- Main CSS File -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/assets/css/demo3.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/website/assets/vendor/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/website/assets/vendor/simple-line-icons/css/simple-line-icons.min.css')); ?>">
</head>

<body class="full-screen-slider">
    <div class="page-wrapper">
        <header class="header header-transparent">
            <div class="header-middle sticky-header">
                <div class="container">
                  <?php echo $__env->make('layouts.includes.website.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- End .header- -->
                </div><!-- End .container -->
            </div><!-- End .header-middle -->
        </header><!-- End .header -->
<?php echo $__env->yieldContent('main'); ?>

		<footer class="footer bg-dark">
			<div class="footer-middle">
				<div class="container text-light">
					<div class="row">
						<div class="col-lg-6 col-sm-6">
							<div class="widget">
								<h4 class="widget-title text-light">About</h4>
								<ul class="contact-info">
									<li>
										<span class="contact-info-label">Address:</span>123 Street Name, City, England
									</li>
									<li>
										<span class="contact-info-label">Phone:</span><a href="tel:">(123)
											456-7890</a>
									</li>
									<li>
										<span class="contact-info-label">Email:</span> <a
											href="mailto:mail@example.com">mail@example.com</a>
									</li>
									<li>
										<span class="contact-info-label">Working Days/Hours:</span>
										Mon - Sun / 9:00 AM - 8:00 PM
									</li>
								</ul>
								<div class="social-icons">
									<a href="#" class="social-icon social-facebook icon-facebook" target="_blank"
										title="Facebook"></a>
									<a href="#" class="social-icon social-twitter icon-twitter" target="_blank"
										title="Twitter"></a>
									<a href="#" class="social-icon social-instagram icon-instagram" target="_blank"
										title="Instagram"></a>
								</div><!-- End .social-icons -->
							</div><!-- End .widget -->
						</div><!-- End .col-lg-3 -->

						<div class="col-lg-6 col-sm-6">
							<div class="widget">
								<h4 class="widget-title text-light">Customer Service</h4>

								<ul class="links">
									<li><a href="#">Help & FAQs</a></li>
									
									<li><a href="#">Careers</a></li>
									<li><a href="#">About Us</a></li>
									<li><a href="#">Corporate Sales</a></li>
									<li><a href="#">Privacy</a></li>
								</ul>
							</div><!-- End .widget -->
						</div><!-- End .col-lg-3 -->

						

				
					</div><!-- End .row -->
				</div><!-- End .container -->
			</div><!-- End .footer-middle -->

			<div class="container">
				<div class="footer-bottom">
					<div class="container d-sm-flex align-items-center">
						<div class="footer-left">
							<span class="footer-copyright">© Porto eCommerce. 2021. All Rights Reserved</span>
						</div>

					
					</div>
				</div><!-- End .footer-bottom -->
			</div><!-- End .container -->
		</footer><!-- End .footer -->
    <a id="scroll-top" href="#top" title="Top" role="button"><i class="icon-angle-up"></i></a>
  <div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

    <div class="mobile-menu-container">
        <div class="mobile-menu-wrapper">
            <span class="mobile-menu-close"><i class="fa fa-times"></i></span>
            <nav class="mobile-nav">
                <ul class="mobile-menu">
                  
                                <li class="active">
                                    <a href="<?php echo e(route('home')); ?>">Home</a>
                                </li>
                                <li>
                                    <a href="#">Categories</a>
                                    <div class="megamenu megamenu-fixed-width megamenu-3cols">
                                        <div class="row">
                                            <div class="col-lg-4">
                                               
                                                <ul class="submenu">
                                                  <?php $__currentLoopData = App\Models\Category::with('subCategory')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <li><a href="<?php echo e(route('category_product',$category->id)); ?>"><?php echo e($category->name); ?></a>
                                                            
                                                    </li>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                   
                                                </ul>
                                            </div>
                                           
                                           
                                        </div>
                                    </div><!-- End .megamenu -->
                                </li>
                                <li>
                                    <a href="<?php echo e(route('products')); ?>">Products</a>
                                   
                                </li>
                                <li><a href="<?php echo e(route('blogs')); ?>">Blog</a></li>
                                 <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                  <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                            </ul>
               
            </nav><!-- End .mobile-nav -->

           

          
        </div><!-- End .mobile-menu-wrapper -->
    </div><!-- End .mobile-menu-container -->

    <!-- Plugins JS File -->
    <script src="<?php echo e(asset('assets/website/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/assets/js/plugins.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/assets/js/jquery.appear.min.js')); ?>"></script>

    <!-- Main JS File -->
    <script src="<?php echo e(asset('assets/website/assets/js/main.min.js')); ?>"></script>
</body>


<!-- Mirrored from portotheme.com/html/porto_ecommerce/demo3.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Mar 2022 07:08:48 GMT -->
</html><?php /**PATH C:\laragon\www\starter-project\resources\views/layouts/includes/website/main.blade.php ENDPATH**/ ?>