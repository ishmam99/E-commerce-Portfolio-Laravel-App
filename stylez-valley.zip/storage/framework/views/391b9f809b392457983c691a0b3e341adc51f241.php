

<?php $__env->startSection('content'); ?>
  
  <div class="card card-custom card-sticky" id="kt_page_sticky_card">
    <?php if(session()->has('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
    <?php elseif(session()->has('error')): ?>
      <div class="alert alert-titlenger">
        <?php echo e(session()->get('error')); ?>

      </div>
    <?php endif; ?>
    <div class="card-header">
    
      <div class="card-toolbar">
        <a href="<?php echo e(route('sliders.index')); ?>" class="btn btn-light-primary font-weight-bolder mr-2">
          <i class="ki ki-long-arrow-back icon-sm"></i>
          Back
        </a>
        <div class="btn-group">
          <button type="submit" form="kt_form" class="btn btn-primary font-weight-bolder submit">
            <i class="ki ki-check icon-sm"></i>
          
          </button>
        </div>
      </div>
    </div>
    <div class="card-body">
      <!--begin::Form-->
    
        <div class="row">
          <div class="col-xl-2"></div>
          <div class="col-xl-8">
            <div class="my-5">

             

              <div class="form-group row">
                <label class="col-md-3 col-form-label" for="title">Title <span class="text-danger"></span></label>
                <div class="col-md-9">
                  <span><?php echo e($slider->name); ?></span>
                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-titlenger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

               <div class="form-group row">
                <label class="col-md-3 col-form-label" for="title">Discount Text <span class="text-danger"></span></label>
                <div class="col-md-9">
                  <span><?php echo e($slider->discount); ?></span>
                
                </div>
              </div>
               <div class="form-group row">
                <label class="col-md-3 col-form-label" for="title">Product Text <span class="text-danger"></span></label>
                <div class="col-md-9">
                  <span><?php echo e($slider->product); ?></span>
                 
                </div>
              </div>
              <div class="form-group row">
                <label class="col-md-3 col-form-label" for="title">Product Text Color <span class="text-danger"></span></label>
                <div class="col-md-9">
                  <span><?php echo e($slider->color); ?></span>
                 
                </div>
              </div>
              
              <div class="form-group row">
                <label class="col-md-3 col-form-label" for="pa">Slider <span class="text-titlenger"></span></label>
                <div class="col-md-9">
                 <img src="<?php echo e(setImage($slider->photo)); ?>" width="100%" height="100%">
                </div>
              </div>
         
              <div class="form-group row">
                <label class="col-md-3 col-form-label" for="status">Publish</label>
                <div class="col-md-9">
               
                  <span class="switch switch-icon">
                  <label>
                    <input type="checkbox" <?php echo e($slider->status == 0 ?'checked':''); ?> value="1" name="status"/>
                    <span></span>
                  </label>
                </span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-2"></div>
        </div>
      </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spinnertechltd/stylez-valley.spinnertechltd.com/resources/views/dashboard/slider/view.blade.php ENDPATH**/ ?>