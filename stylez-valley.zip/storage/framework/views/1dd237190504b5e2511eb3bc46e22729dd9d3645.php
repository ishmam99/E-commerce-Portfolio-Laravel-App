

<?php $__env->startSection('content'); ?>
  
  <div class="card card-custom card-sticky" id="kt_page_sticky_card">
    <?php if(session()->has('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
    <?php elseif(session()->has('error')): ?>
      <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

      </div>
    <?php endif; ?>
    <div class="card-header">
     
      <h3>Public Message</h3>
    </div>
    <div class="card-body">
      <!--begin::Form-->
      <div class="row">
    <h4 class="card col-3">Name :</h4> <h4 class="card col-9"> <?php echo e($message->name); ?></h4>
    <h4 class="card col-3">Email :</h4><h4 class="card col-9"> <?php echo e($message->email); ?></h4>
    <h4 class="card col-3"> Details : </h4><p class="card col-9"><?php echo e($message->message); ?></p>
    <h4 class="card col-3">Attachment : </h4><img src="<?php echo e(setImage($message->attachment)); ?>" width="200px" alt="" class="card col-9">
  </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\starter-project\resources\views/dashboard/message/show.blade.php ENDPATH**/ ?>