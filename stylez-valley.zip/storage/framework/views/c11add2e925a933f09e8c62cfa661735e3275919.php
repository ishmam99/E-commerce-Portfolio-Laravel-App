
<?php $__env->startSection('main'); ?>
   
    
      <main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="demo4.html"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Blog Post</li>
					</ol>
				</div><!-- End .container -->
			</nav>

			<div class="container">
				<div class="row">
					<div class="col-lg-9">
						<article class="post single">
							<div class="post-media">
								<img src="<?php echo e(setImage($blog->image)); ?>" height="50px" width="50px"alt="Post">
							</div><!-- End .post-media -->

							<div class="post-body">
								<div class="post-date">
											<span class="day"><?php echo e(Carbon\Carbon::parse($blog->created_at)->isoFormat(' DD')); ?></span>
											<span class="month"><?php echo e(Carbon\Carbon::parse($blog->created_at)->isoFormat(' MMM')); ?></span>
										</div>

								<h2 class="post-title"><?php echo e($blog->title); ?></h2>

								

								<div class="post-content">
									<p><?php echo e($blog->details); ?>

									</p>

									
								</div><!-- End .post-content -->

								<div class="post-share">
									<h3 class="d-flex align-items-center">
										<i class="fas fa-share"></i>
										Share this post
									</h3>

									

								

							
							</div><!-- End .post-body -->
						</article><!-- End .post -->

						<hr class="mt-2 mb-1">

						
					</div><!-- End .col-lg-9 -->

					
					<div class="sidebar-overlay"></div>
				
				</div><!-- End .row -->
			</div><!-- End .container -->
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.includes.website.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\starter-project\resources\views/website/blog-single.blade.php ENDPATH**/ ?>