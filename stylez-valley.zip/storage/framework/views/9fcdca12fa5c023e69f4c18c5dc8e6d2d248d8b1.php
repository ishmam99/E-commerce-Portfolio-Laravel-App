

<?php $__env->startSection('content'); ?>

  <div class="card card-custom">
    <?php if(session()->has('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
    <?php elseif(session()->has('error')): ?>
      <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

      </div>
    <?php endif; ?>
    <div class="card-header flex-wrap border-0 pt-6 pb-0">
      <div class="card-title">
        <h3 class="card-label">Message List</h3>
      </div>
    
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-separate table-head-custom table-checkable" id="kt_datatable">
          <thead>
            <tr>
              <th>SL</th>
              <th>Name</th> 
              <th>Email</th>
              <th>Attachment</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration + $messages->firstItem() - 1); ?></td>
                <td><?php echo e($message->name); ?></td>
                <td><?php echo e($message->email); ?></td>
                <td> <img style="width: 50px;" src="<?php echo e(setImage($message->attachment)); ?>" alt=""></td>
                <td><a href="<?php echo e(route('message.show',$message->id)); ?>">Details</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <?php echo e($messages->links()); ?>

    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\starter-project\resources\views/dashboard/message/index.blade.php ENDPATH**/ ?>