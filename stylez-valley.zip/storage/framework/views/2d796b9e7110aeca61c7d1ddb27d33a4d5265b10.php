
<?php $__env->startSection('main'); ?>
   
    
        <main class="main">
            <div class="category-banner-container bg-gray">
                <div class="category-banner banner text-uppercase" >
                    <div class="container position-relative">
                        <div class="row">
                            
                            <div class="pl-lg-3 col-md-4 offset-md-0 offset-1 pt-3">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <nav aria-label="breadcrumb" class="breadcrumb-nav">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Products</li>
                    </ol>
                </nav>

                

                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    <div class="col-6 col-sm-4 col-md-3 col-xl-5col">
                        <div class="product-default">
                            <figure>
                                <a href="<?php echo e(route('show_product',$product->id)); ?>">
                                    <img src="<?php echo e(setImage($product->image_one)); ?>" width="100%" height="220px" alt="product" />
                                    <img src="<?php echo e(setImage($product->image_two)); ?>" width="220" height="220" alt="product" />
                                </a>

                                
                            </figure>

                            <div class="product-details">
                                <div class="category-wrap">
                                    <div class="category-list">
                                        <a href="<?php echo e(route('category_product',$product->subCategory->id)); ?>" class="product-category"><?php echo e($product->subCategory->name); ?></a>
                                    </div>
                                </div>

                                <h3 class="product-title"> <a href="<?php echo e(route('show_product',$product->id)); ?>"><?php echo e($product->name); ?></a>
                                </h3>

                                <div class="ratings-container">
                                    <div class="product-ratings">
                                        <span class="ratings" style="width:100%"></span>
                                        <!-- End .ratings -->
                                        <span class="tooltiptext tooltip-top"></span>
                                    </div>
                                    <!-- End .product-ratings -->
                                </div>
                                <!-- End .product-container -->

                                <div class="price-box">
                                   
                                    <span class="product-price">$<?php echo e($product->price); ?></span>
                                </div>
                                <!-- End .price-box -->

                                
                            </div>
                            <!-- End .product-details -->
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End .col-sm-4 -->

                    
                    <!-- End .col-sm-4 -->

                    
                    <!-- End .col-sm-4 -->
                </div>
                <!-- End .row -->

                <nav class="toolbox toolbox-pagination">
                    
                    <!-- End .toolbox-item -->

                    <ul class="pagination toolbox-item">
                       
                        <li class="page-item active">
                            <?php echo e($products->links()); ?>

                        </li>
                    
                           
                    </ul>
                </nav>
            </div>
            <!-- End .container -->
            
            <!-- End .col-lg-3 -->

            <div class="mb-3"></div>
            <!-- margin -->
        </main>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.includes.website.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spinnertechltd/stylez-valley.spinnertechltd.com/resources/views/website/product.blade.php ENDPATH**/ ?>