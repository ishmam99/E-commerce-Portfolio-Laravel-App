 <h2 class="section-title ls-n-15 text-center pt-2 m-b-4">Shop By Category</h2>

                <div class="owl-carousel owl-theme nav-image-center show-nav-hover nav-outer cats-slider appear-animate"
                    data-animation-name="fadeInUpShorter" data-animation-delay="200" data-animation-duration="1000">
                    <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                   
                    <div class="product-category">
                        <a href="<?php echo e(route('category_product',$category->id)); ?>">
                            <figure>
                                <img style="max-width: 100%; width:100%;height:215px;" src="<?php echo e(setImage($category->image)); ?>"
                                    alt="category" />
                            </figure>
                            <div class="category-content">
                                <h3><?php echo e($category->name); ?></h3>
                                <span><mark class="count"></mark> products</span>
                            </div>
                        </a>
                    </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
            <?php /**PATH C:\laragon\www\starter-project\resources\views/layouts/includes/website/container.blade.php ENDPATH**/ ?>