<div class="header-left">
                        <button class="mobile-menu-toggler" type="button">
                            <i class="fas fa-bars"></i>
                        </button>

                        <link href='https://fonts.googleapis.com/css?family=Rubik Glitch' rel='stylesheet'>
                        <a href="<?php echo e(route('home')); ?>" class="logo">
                            <img src="<?php echo e(asset('assets/website/assets/images/logo-white.png')); ?>" style="margin: 0 auto;" alt="Porto Logo"> 
                          
                        </a>


                        <nav class="main-nav font2">
                            <ul class="menu">
                                <li class="active">
                                    <a href="<?php echo e(route('home')); ?>">Home</a>
                                </li>
                                <li>
                                    <a href="#">Categories</a>
                                    <div class="megamenu megamenu-fixed-width megamenu-3cols">
                                        <div class="row">
                                            <div class="col-lg-4">
                                               
                                                <ul class="submenu ">
                                                  <?php $__currentLoopData = App\Models\Category::with('subCategory')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <li><a href="#"><?php echo e($category->name); ?></a>
                                                            <ul class="submenu" style="position: relative">
                                                                <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li> <a href="<?php echo e(route('category_product',$subcategory->id)); ?>"><?php echo e($subcategory->name); ?></a></li>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                            </ul>  
                                                    </li>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                   
                                                </ul>
                                            </div>
                                          
                                        </div>
                                    </div><!-- End .megamenu -->
                                </li>
                                <li>
                                    <a href="<?php echo e(route('products')); ?>">Products</a>
                                   
                                </li>
                                <li><a href="<?php echo e(route('blogs')); ?>">Blog</a></li>
                                 <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                  <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                            </ul>
                        </nav>
                    </div><!-- End .header-left -->

                    <?php /**PATH /home/spinnertechltd/stylez-valley.spinnertechltd.com/resources/views/layouts/includes/website/header.blade.php ENDPATH**/ ?>